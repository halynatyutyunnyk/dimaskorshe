﻿<?php
$en_lang = array (
"Identifier_1"=>'String for translation 1',
"Identifier_2"=>'String for translation 2',
"Identifier_3"=>'String for translation 3',
"Identifier_4"=>'String for translation 4',
"Identifier_5"=>'String for translation 5',
);
extract($en_lang);
?>